@echo off
setlocal
rem === AYRA Tennis - Speed update applier (run after extracting) ===
set "GAME="
for %%D in ("%USERPROFILE%\Desktop\AYRA_TENNIS_MINI_PC" "%USERPROFILE%\OneDrive\Desktop\AYRA_TENNIS_MINI_PC" "%USERPROFILE%\OneDrive\Y????????????\AYRA_TENNIS_MINI_PC") do (
  if exist "%%~D\server.mjs" set "GAME=%%~D"
)
if not defined GAME (
  echo.
  echo Could not find AYRA_TENNIS_MINI_PC automatically.
  echo Copy dist\index.html and START_EVENT.cmd into your game folder by hand.
  echo.
  pause
  exit /b 1
)
echo Updating: %GAME%
copy /y "%~dp0dist\index.html" "%GAME%\dist\index.html" >nul
copy /y "%~dp0START_EVENT.cmd" "%GAME%\START_EVENT.cmd" >nul
echo.
echo ============================================
echo   DONE! Speed update applied.
echo   Now run START_EVENT.cmd inside AYRA_TENNIS_MINI_PC
echo ============================================
echo.
pause
