@echo off
setlocal
cd /d "%~dp0"

rem ===== AYRA x POWERADE Tennis - EVENT launcher =====
set "PORT=4292"
rem perf mode: KEEP the full approved stadium + full crowd — only render at lower resolution + drop shadows
rem (content identical; just softer). Tune render scale: &rs=0.45 (lighter) ... &rs=0.75 (sharper)
set "KIOSK_URL=http://localhost:%PORT%/?perf&rs=0.55"

rem Public URL for the phone QR. Put your tunnel domain in PUBLIC_URL.txt
rem (e.g. https://game.evlabsai.gr). Without it, phones on other networks cannot open the QR.
if exist "PUBLIC_URL.txt" (
  set /p PUBLIC_BASE_URL=<PUBLIC_URL.txt
  echo QR link base: %PUBLIC_BASE_URL%
) else (
  echo [!] PUBLIC_URL.txt missing - QR will use localhost only.
)

where node >nul 2>nul
if errorlevel 1 (
  echo [X] Node.js not found. Install Node LTS from https://nodejs.org then retry.
  pause
  exit /b 1
)

echo Starting Tennis server on port %PORT% ...
start "AYRA Tennis Server" /min node server.mjs

rem give the server a moment, then open fullscreen kiosk
timeout /t 3 /nobreak >nul

set "CHROME="
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
set "EDGE="
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"

if defined CHROME (
  "%CHROME%" --kiosk --start-fullscreen --overscroll-history-navigation=0 "%KIOSK_URL%"
) else if defined EDGE (
  "%EDGE%" --kiosk "%KIOSK_URL%" --edge-kiosk-type=fullscreen --no-first-run
) else (
  echo Chrome/Edge not found - opening default browser. Press F11 for fullscreen.
  start "" "%KIOSK_URL%"
)

endlocal
